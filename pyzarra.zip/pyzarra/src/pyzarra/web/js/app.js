/**
 * Puente JavaScript -> Python
 *
 * IMPORTANTE: window.pywebview.api NO existe al cargar la pagina.
 * Hay que esperar al evento 'pywebviewready'.
 */

window.addEventListener('pywebviewready', () => {
  console.log('Python conectado');
  iniciar();
});

function iniciar() {
  const api = window.pywebview.api;

  // --- Ejemplo 1: saludar ---
  document.getElementById('btn-saludar').addEventListener('click', async () => {
    const nombre = document.getElementById('nombre').value || 'desconocido';
    const texto = await api.saludar(nombre);
    document.getElementById('resultado-saludo').textContent = texto;
  });

  // --- Ejemplo 2: info del sistema ---
  document.getElementById('btn-info').addEventListener('click', async () => {
    const datos = await api.info_sistema();
    document.getElementById('resultado-info').textContent =
      JSON.stringify(datos, null, 2);
  });
}
